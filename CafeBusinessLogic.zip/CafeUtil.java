import java.util.ArrayList;

public class CafeUtil {

  public int getStreakGoal() {
    int sum = 0;
    for (int i=1; i<=10; i++) {
      sum += i;
    }
    return sum;
  }

  public double getOrderTotal(double[] prices) {
    double total = prices[0] + prices[1] + prices[2] + prices[3];
    return total;
  }

  public void displayMenu(ArrayList<String> menuItems) {
    for(int i=0; i < menuItems.size(); i++) {
      System.out.println(i + " " + menuItems.get(i));
    }
  }

  public void addCustomer(ArrayList<String> name) {
    System.out.println("Please enter your name");

    String userName = System.console().readLine();

    System.out.println("Hello, " + userName + " !");
    
    System.out.println("There are " + name.size() + " people in front of you.");
    
    name.add(userName);
    System.out.println(name);
    // String realName = name.add(userName);
    // System.out.println(realName);
  }
}